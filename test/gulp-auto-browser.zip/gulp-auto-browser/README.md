# gulp-auto-browser

 gulp自动化环境

## Usage

* step1
```
    npm install 
```

* step2
```
    gulp 
```

* step3
```
    打开浏览器输入网址
```
* step4<br/>    
    完成安装之后，即可通过点击此链接打开网页<br/>
    [http://localhost:8080/src/test.html](http://localhost:8080/src/test.html)
